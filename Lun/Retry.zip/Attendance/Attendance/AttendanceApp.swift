//
//  AttendanceApp.swift
//  Attendance
//
//  Created by itst on 19/12/2024.
//

import SwiftUI

@main
struct AttendanceApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
